# SPDX-FileCopyrightText: 2026 Blender Authors
# SPDX-License-Identifier: GPL-3.0-or-later

import os
import sys
from pathlib import Path
from typing import Callable, NoReturn


def loop_via_blender(callback: Callable[[], NoReturn], script_path: Path) -> NoReturn:
    """Use Blender to run this script again.

    If already inside Blender, call the callback function.
    """

    if _is_inside_blender():
        callback()

    import shlex
    import subprocess

    blender_exe = _find_blender_exe(script_path)

    # Construct CLI arguments for Blender.
    args = [blender_exe]

    if not os.environ.get("BAT_BLENDER_VERBOSE", ""):
        args.append("-q")

    args.extend(
        [
            "-b",
            "--factory-startup",
            "--python-exit-code",
            "47",
        ]
    )

    # Make sure that BAT can be found wherever it was installed.
    # If currently running inside a virtualenv, reactivate it in Blender.
    # This assumes that the virtualenv is correctly set up and contains BAT.
    if venv := os.environ.get("VIRTUAL_ENV"):
        venv_path = Path(venv)
        match sys.platform:
            case "win32":
                site_dir = venv_path / "Lib/site-packages"
            case _:
                site_dir = next(venv_path.glob("lib/python*/site-packages"))
        assert site_dir.is_dir(), site_dir

        add_site_code = "import site; site.addsitedir({!r})".format(str(site_dir))
        args.extend(["--python-expr", add_site_code])
    else:
        # No virtualenv means that BAT still needs to be located. Assume it is
        # installed nicely in some sitedir.
        bat_site_dir = Path(__file__).resolve().parent.parent
        add_site_code = f"import site; site.addsitedir({str(bat_site_dir)!r})"
        args.extend(["--python-expr", add_site_code])

    # Finally, add the script to run.
    args.extend(["-P", str(script_path)])

    # Forward CLI arguments to the re-run of the script in Blender.
    if len(sys.argv) > 1:
        args.append("--")
        args.extend(sys.argv[1:])

    # Bit of a hack: see if '-d' or '--debug' were passed to BAT, and then show
    # which command is run. It's a hack because it ignores the distinction
    # between arguments before and after the BAT sub-command.
    if {"-d", "--debug"} & set(sys.argv):
        print(f"{script_path.stem}: Running via Blender:")
        print(f"{script_path.stem}: {shlex.join(args)}")
        print()

    proc = subprocess.run(args)
    raise SystemExit(proc.returncode)


def _is_inside_blender() -> bool:
    """Return whether this script runs inside Blender or not."""
    # Ensure mypy can import bpy, so that it can do proper checking of imports.
    try:
        import bpy  # pyright: ignore[reportMissingImports]
    except ImportError:
        return False

    # Call a function to see if the bpy interface is actually functional, and not some fake-bpy module.
    try:
        return bool(bpy.app.memory_usage_undo() >= 0)
    except (AttributeError, TypeError):
        # AttributeError happens when there is no bpy.app or bpy.app.memory_usage_undo.
        # TypeError happens when it's not a function, or when the function's return value
        # cannot be compared to an integer.
        return False


def _find_blender_exe(script_path: Path) -> str:
    """Find the Blender executable, either from $PATH or $BAT_BLENDER."""
    import shutil

    bat_blender_env = os.environ.get("BAT_BLENDER") or ""
    blender_exe = shutil.which(bat_blender_env or "blender")
    if blender_exe is not None:
        return blender_exe

    if bat_blender_env:
        print(
            f"Cannot find blender executable, tried {bat_blender_env} from BAT_BLENDER:",
            file=sys.stderr,
        )
    else:
        print("Cannot find blender executable, set BAT_BLENDER:", file=sys.stderr)

    match sys.platform:
        case "win32":
            path = r"C:\Program Files\Blender Foundation\Blender 5.1\blender"
            print(f'  SET BAT_BLENDER="{path}"', file=sys.stderr)
            print(f"python {script_path.name} --help", file=sys.stderr)
        case _:
            path = "/path/to/blender"
            print(
                f"env BAT_BLENDER={path} python3 {script_path.name} --help",
                file=sys.stderr,
            )

    raise SystemExit(47)
